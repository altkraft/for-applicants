import React from 'react';
import './App.scss';
import ReactLogo from '../logo.svg';

function App() {
    return (
        <div className="container">
            <div>
                <ReactLogo width={400} height={400} />
            </div>
            <h1>Hello!</h1>
            <p>Just start editing src/App/App.tsx</p>
        </div>
    );
}

export default App;
